document.addEventListener("DOMContentLoaded", () => {
  console.log("Bekam Home Care Bandung website aktif.");
});